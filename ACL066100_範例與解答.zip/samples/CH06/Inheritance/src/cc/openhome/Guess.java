package cc.openhome;

public class Guess {
    public static void main(String[] args) {
        GuessGame game = new ConsoleGame();
        game.go();
    }
}
