package cc.openhome.test;

public class Test {
    public static void fromTestModule() {
        System.out.println("來自 cc.openhome.test 模組");
    }
}
