module Game6 {
}