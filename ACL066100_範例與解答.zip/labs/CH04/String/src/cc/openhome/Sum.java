package cc.openhome;

import java.util.Scanner;

public class Sum {
    public static void main(String[] args) {
        var console = new Scanner(System.in);
        
        var sum = 0;
        var number = 0;

            /*
             補上程式碼
             */
             
        System.out.println("總合：" + sum);
    }
}
