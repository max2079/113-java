module Encapsulation2 {
}