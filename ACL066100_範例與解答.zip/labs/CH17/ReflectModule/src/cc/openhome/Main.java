package cc.openhome;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException {
        var clz = Class.forName("cc.openhome.reflect.Some");
    }
}