package cc.openhome;

import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
public @interface ClientAdded {}