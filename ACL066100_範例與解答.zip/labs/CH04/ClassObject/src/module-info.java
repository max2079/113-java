module ClassObject {
}