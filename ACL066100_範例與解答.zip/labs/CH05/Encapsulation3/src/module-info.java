module Encapsulation3 {
}