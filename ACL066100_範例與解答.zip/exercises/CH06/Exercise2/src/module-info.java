module Exercise2 {
}