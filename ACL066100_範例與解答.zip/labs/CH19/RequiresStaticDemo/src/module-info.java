module cc.openhome {
    requires cc.openhome.test;
}