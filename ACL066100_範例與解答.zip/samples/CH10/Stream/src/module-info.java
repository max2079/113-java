module Stream {
	requires java.net.http;
}