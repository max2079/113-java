module cc.openhome.test {
	exports cc.openhome.test;
} 