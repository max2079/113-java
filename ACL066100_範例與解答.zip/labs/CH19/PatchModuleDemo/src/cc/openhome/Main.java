package cc.openhome;

public class Main {
    public static void main(String[] args) {
        cc.openhome.util.Util.help();
    }
}
