package cc.openhome;

interface IntegerFunction {
    Integer apply(Integer i);
}


public class Demo {
    public static void main(String[] args) {
        
        IntegerFunction doubleFunction = i -> i * 2;
        

        
        
    }
}
