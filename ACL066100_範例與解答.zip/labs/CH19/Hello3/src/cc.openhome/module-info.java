module cc.openhome {
    requires cc.openhome.util;
}