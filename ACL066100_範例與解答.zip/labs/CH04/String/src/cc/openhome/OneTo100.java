package cc.openhome;

public class OneTo100 {
    public static void main(String[] args) {
        /*
         * 怎麼顯示1+2+3+.....+100？
         */
    }
}
