module cc.openhome.impl {
	requires cc.openhome.api;
}