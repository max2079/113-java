package cc.openhome;

public class IrregularArray {
    public static void main(String[] args) {
        /*
         * �ɤW�{���X
         * /
    }
}
