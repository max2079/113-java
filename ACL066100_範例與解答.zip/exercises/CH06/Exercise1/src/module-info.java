module Exercise1 {
}