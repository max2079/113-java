module Basic {
}