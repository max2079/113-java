module Exercise {
    requires com.h2database;
    requires java.sql;
}