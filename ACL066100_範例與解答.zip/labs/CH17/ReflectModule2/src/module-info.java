module cc.openhome {
	requires cc.openhome.reflect;
}