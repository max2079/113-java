package cc.openhome;

public interface Swimmer {
    public abstract void swim();
}
