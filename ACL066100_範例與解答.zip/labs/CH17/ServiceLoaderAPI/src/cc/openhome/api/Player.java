package cc.openhome.api;

public interface Player { 
    void play(String video);    
}
