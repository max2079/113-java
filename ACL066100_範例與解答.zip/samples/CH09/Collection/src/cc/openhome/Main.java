package cc.openhome;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		var names = new ArrayList<>();
		names.add("Justin");
		names.add("Monica");
		names.add(1);

		
		
		
	}

}
