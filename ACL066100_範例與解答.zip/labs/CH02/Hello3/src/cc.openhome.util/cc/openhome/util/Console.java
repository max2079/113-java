package cc.openhome.util;

public class Console {
    public static void writeLine(String text) {
	    System.out.println(text);
	}
}