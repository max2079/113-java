module cc.openhome {
	requires cc.openhome.api;
}