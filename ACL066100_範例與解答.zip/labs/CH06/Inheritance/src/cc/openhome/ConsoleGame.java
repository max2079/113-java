package cc.openhome;

import java.util.Scanner;

public class ConsoleGame extends GuessGame {
    /*
     實作程式內容
     */
}
