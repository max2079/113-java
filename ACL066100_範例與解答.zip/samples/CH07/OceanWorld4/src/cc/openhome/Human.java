package cc.openhome;

public class Human {
    protected String name;
    
    public Human(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
}
