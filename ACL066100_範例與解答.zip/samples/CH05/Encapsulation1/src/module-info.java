module Encapsulation1 {
}