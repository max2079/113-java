package cc.openhome;

public enum Action {
    STOP, RIGHT, LEFT, UP, DOWN
}
