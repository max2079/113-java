package cc.openhome.reflect;

public class Some {
    private String some;
    public Some(String some) {
        this.some = some;
    }
    public void doSome() {
        System.out.println(some);
    }
}
