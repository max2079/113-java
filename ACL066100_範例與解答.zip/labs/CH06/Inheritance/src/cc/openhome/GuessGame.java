package cc.openhome;

public abstract class GuessGame {
    /*
     * 實作程式內容
     * 
     */
}
