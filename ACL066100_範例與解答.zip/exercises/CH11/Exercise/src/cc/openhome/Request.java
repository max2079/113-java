package cc.openhome;
public interface Request {
    void execute();
}