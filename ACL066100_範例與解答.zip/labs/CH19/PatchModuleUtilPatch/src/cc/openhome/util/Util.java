package cc.openhome.util;

public class Util {
    public static void help() {
        System.out.println("HELP");
    }
}
