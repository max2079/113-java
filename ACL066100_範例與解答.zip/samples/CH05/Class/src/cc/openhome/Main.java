package cc.openhome;



public class Main {
	static class Some {
	    static class Other {
	    }
	}
	
	public static void main(String[] args) {
		var o = new Some.Other();
	}

}
