package cc.openhome;

import java.math.BigDecimal;

public class DecimalDemo2 {
    public static void main(String[] args) {
        /*
         * �ɤW�{���X
         */
    }
} 
