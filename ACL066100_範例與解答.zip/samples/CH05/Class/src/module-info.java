module Class {
}