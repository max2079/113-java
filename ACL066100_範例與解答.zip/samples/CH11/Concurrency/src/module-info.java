module Concurrency {
	requires java.net.http;
}