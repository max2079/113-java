module Exercise3 {
}